package com.company.java001_ex;

public class A002_ex {
	public static void main(String[] args) { 
		System.out.println("X\nXY\nXYZ");
		
		// 	도시 : 인천  ,  인구:1000000
		System.out.printf("도시 : %s  , 인구: %d" , "인천", 1000000);
	}
}
/* Q
package : com.company.java001_ex
class   : A002_ex
문제 : 다음을 한줄로, 포맷형식에 맞게 처리하시오
    // 다음을 한 줄 출력
        System.out.println("X");
        System.out.println("XY");
        System.out.println("XYZ");
    // 포맷형식이용해서 출력	

출력내용  : 
	X
	XY
	XYZ

	도시 : 인천  ,  인구:1000000
*/
