package com.company.java001_ex;

public class A001_ex {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
/* Q
package : com.company.java001_ex
class   : A001_ex
출력내용  : Hello World! 
*/