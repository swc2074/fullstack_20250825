package com.company.java002_ex;

public class PrintEx002 {
	public static void main(String [] args) {
		 System.out.println(  10 +"+"+3+"="+(10+3)  );
		 System.out.println(  "10+3=" + (10+3)  );
		 System.out.printf(   "%d+%d=%d" , 10,3,(10+3) );
	}
}
/*
연습문제2)  
패키지명 : com.company.java002_ex
클래스명 : PrintEx002
출력내용 : 
   다음의 코드를 10+3=13  나오게 도전!
   System.out.println(  10+3=10+3  )

*/