package com.company.java002_ex;

public class PrintEx001 {
	public static void main(String[] args) {
		//println
		System.out.println("좋아하는 색상은 RED입니다.");
		
		//print      print+\n -> println
		System.out.print("좋아하는 색상은 RED입니다.\n");
		
		//printf
		System.out.printf("좋아하는 색상은 %s입니다", "RED");
	}
}
/*
연습문제1)  
패키지명 : com.company.java002_ex
클래스명 : PrintEx001
출력내용 : 
   println, print, printf를 이용해서 
   다음을 3번출력하세요!
     
    좋아하는 색상은 RED입니다.

*/